import { v4 as uuidv4 } from 'uuid';
import { SHAREPOINT_GRAPH_URL, SHAREPOINT_SITE_URL, SHAREPOINT_MEMBERS_LIST_NAME, SHAREPOINT_ENTRIES_LIST_NAME } from '../constants';
import type { Member } from '../types';
import { sanitizeMember, sanitizeString } from '../utils';

// Helper to make authenticated requests to MS Graph API
async function graphRequest(url: string, accessToken: string, options: RequestInit = {}) {
    const headers = new Headers(options.headers || {});
    headers.append('Authorization', `Bearer ${accessToken}`);
    if (!headers.has('Content-Type') && options.method && ['POST', 'PUT', 'PATCH'].includes(options.method)) {
        headers.append('Content-Type', 'application/json');
    }

    const response = await fetch(url, { ...options, headers });

    if (!response.ok) {
        const errorText = await response.text();
        try {
            const errorJson = JSON.parse(errorText);
            throw new Error(`Graph API error: ${errorJson.error?.message || response.statusText}`);
        } catch {
             throw new Error(`Graph API error: ${response.status} ${response.statusText}`);
        }
    }

    if (response.status === 204) { // No Content
        return null;
    }

    return response.json();
}

// Maps a SharePoint list item to our app's Member type
function mapSpItemToMember(item: any): Member {
    return sanitizeMember({
        spId: item.id,
        id: item.fields.ID,
        name: item.fields.Title,
        classNumber: item.fields.ClassNumber,
    });
}

// Maps our app's Member type to a SharePoint list item format for saving
function mapMemberToSpItem(member: Omit<Member, 'id'> & { id?: string }): any {
    const newId = member.id || uuidv4();
    return {
        id: newId, // Return the ID so we can use it in the UI immediately
        fields: {
            Title: member.name,
            ID: newId,
            ClassNumber: member.classNumber || '',
        }
    };
}


/**
 * Constructs a SharePoint site URL for Graph API from a user-provided browser URL.
 * Returns null if the URL is invalid or a placeholder.
 * e.g., "https://tenant.sharepoint.com/sites/MySite" -> "/sites/tenant.sharepoint.com:/sites/MySite"
 */
function getSitePath(siteUrl: string): string | null {
    if (!siteUrl || siteUrl.startsWith("PASTE_YOUR")) {
        return null;
    }
    try {
        const url = new URL(siteUrl);
        // A simple check to ensure it looks like a SharePoint URL
        if (!url.protocol.startsWith('http') || !url.hostname.endsWith('.sharepoint.com')) {
             return null;
        }
        return `/sites/${url.hostname}:${url.pathname}`;
    } catch (e) {
        // If it's still not a valid URL after the initial checks, treat as unconfigured.
        console.error("Invalid SharePoint Site URL format:", siteUrl);
        return null;
    }
}


// --- Service Functions ---

export async function getMembers(accessToken: string): Promise<Member[]> {
    const sitePath = getSitePath(SHAREPOINT_SITE_URL);
    if (!sitePath) {
        console.warn("SharePoint URL is not configured; returning empty member list.");
        return [];
    }
    const url = `${SHAREPOINT_GRAPH_URL}${sitePath}/lists/${encodeURIComponent(SHAREPOINT_MEMBERS_LIST_NAME)}/items?expand=fields`;
    const data = await graphRequest(url, accessToken);
    return data.value.map(mapSpItemToMember);
}

export async function addMember(accessToken: string, member: Omit<Member, 'id'> & { id?: string }): Promise<Member> {
    const sitePath = getSitePath(SHAREPOINT_SITE_URL);
    if (!sitePath) {
        throw new Error("Cannot add member: SharePoint is not configured correctly in constants.ts.");
    }
    const newItemPayload = mapMemberToSpItem(member);
    const url = `${SHAREPOINT_GRAPH_URL}${sitePath}/lists/${encodeURIComponent(SHAREPOINT_MEMBERS_LIST_NAME)}/items`;
    const createdItem = await graphRequest(url, accessToken, {
        method: 'POST',
        body: JSON.stringify({ fields: newItemPayload.fields }),
    });
    return mapSpItemToMember(createdItem);
}

export async function updateMember(accessToken: string, member: Member): Promise<Member> {
    const sitePath = getSitePath(SHAREPOINT_SITE_URL);
    if (!sitePath) {
        throw new Error("Cannot update member: SharePoint is not configured correctly in constants.ts.");
    }
    const itemToUpdate = mapMemberToSpItem(member);
    if (!member.spId) throw new Error("SharePoint item ID (spId) is missing. Cannot update.");
    
    const url = `${SHAREPOINT_GRAPH_URL}${sitePath}/lists/${encodeURIComponent(SHAREPOINT_MEMBERS_LIST_NAME)}/items/${member.spId}/fields`;
    const updatedFields = await graphRequest(url, accessToken, {
        method: 'PATCH',
        body: JSON.stringify(itemToUpdate.fields),
    });
    return sanitizeMember({ ...member, name: updatedFields.Title, classNumber: updatedFields.ClassNumber });
}

export async function deleteMember(accessToken: string, member: Member): Promise<void> {
    const sitePath = getSitePath(SHAREPOINT_SITE_URL);
    if (!sitePath) {
        throw new Error("Cannot delete member: SharePoint is not configured correctly in constants.ts.");
    }
    if (!member.spId) throw new Error("SharePoint item ID (spId) is missing. Cannot delete.");
    const url = `${SHAREPOINT_GRAPH_URL}${sitePath}/lists/${encodeURIComponent(SHAREPOINT_MEMBERS_LIST_NAME)}/items/${member.spId}`;
    await graphRequest(url, accessToken, { method: 'DELETE' });
}

export async function testSharePointConnection(accessToken: string): Promise<{ success: boolean; message: string; webUrl?: string; }> {
    const sitePath = getSitePath(SHAREPOINT_SITE_URL);
    if (!sitePath) {
        return { success: false, message: "Connection Failed: The SharePoint Site URL is missing or invalid in constants.ts." };
    }
    try {
        // 1. Test site connection
        const siteData = await graphRequest(`${SHAREPOINT_GRAPH_URL}${sitePath}`, accessToken);
        const webUrl = sanitizeString(siteData.webUrl);
        
        // 2. Test members list connection
        await graphRequest(`${SHAREPOINT_GRAPH_URL}${sitePath}/lists/${encodeURIComponent(SHAREPOINT_MEMBERS_LIST_NAME)}`, accessToken);

        // 3. Test entries list connection
        await graphRequest(`${SHAREPOINT_GRAPH_URL}${sitePath}/lists/${encodeURIComponent(SHAREPOINT_ENTRIES_LIST_NAME)}`, accessToken);

        return { success: true, message: "Connection to SharePoint site, Members list, and Entries list successful!", webUrl };
    } catch (e: any) {
        const errorMessage = e.message || 'An unknown error occurred';
        if (errorMessage.includes('not found')) {
            return { success: false, message: `Connection Failed: The site or a list was not found. Please check your configuration in constants.ts.` };
        }
        return { success: false, message: `Connection Failed: ${errorMessage}` };
    }
}