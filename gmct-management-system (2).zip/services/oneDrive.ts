import type { Dispatch, SetStateAction } from 'react';
import type { CloudState } from '../types';
import { GRAPH_SCOPES, MSAL_CLIENT_ID, MSAL_TENANT_ID } from '../constants';

export async function loadMsal(): Promise<any> {
  const anyWin: any = window as any;
  if (anyWin.msal) return anyWin.msal;
  await new Promise<void>((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://alcdn.msauth.net/browser/2.37.0/js/msal-browser.min.js";
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("Failed to load MSAL"));
    document.head.appendChild(s);
  });
  return (window as any).msal;
}

// FIX: Converted getMsalInstance into a promise-based singleton. This ensures only one
// instance of PublicClientApplication is created and initialized, which is critical for
// preventing race conditions and the "interaction_in_progress" error that occurs when
// multiple MSAL operations (like silent sign-in and manual sign-in) overlap.
let msalInstancePromise: Promise<any> | null = null;

const getMsalInstance = (): Promise<any> => {
    if (msalInstancePromise) {
        return msalInstancePromise;
    }

    msalInstancePromise = (async () => {
        const msal = await loadMsal();

        // The application is configured to work once deployed to a static URL on GitHub Pages.
        // This check prevents MSAL from trying to authenticate from development environments
        // with dynamic URLs (like *.scf.usercontent.goog or localhost), which are not
        // registered as valid Redirect URIs in Azure AD and would cause an AADSTS50011 error.
        const isProdEnvironment = window.location.hostname.includes('github.io');
        if (!isProdEnvironment) {
            console.warn("MSAL features are disabled. The app is not running on a configured GitHub Pages URL.");
            return null;
        }

        if (!MSAL_CLIENT_ID || MSAL_CLIENT_ID.startsWith("PASTE_YOUR")) {
            return null;
        }
        
        const authority = MSAL_TENANT_ID && !MSAL_TENANT_ID.startsWith("PASTE_YOUR")
          ? `https://login.microsoftonline.com/${MSAL_TENANT_ID}`
          : "https://login.microsoftonline.com/common";

        const redirectUri = document.baseURI;

        const pca = new msal.PublicClientApplication({
          auth: {
            clientId: MSAL_CLIENT_ID,
            authority: authority,
            redirectUri: redirectUri,
          },
          cache: { cacheLocation: "localStorage" },
        });

        await pca.initialize();
        return pca;
    })();

    return msalInstancePromise;
};


export async function msalSignIn(setCloud: Dispatch<SetStateAction<CloudState>>): Promise<void> {
  try {
    const pca = await getMsalInstance();
    if (!pca) {
        // The getMsalInstance function now handles environment checks. If it returns null,
        // it means cloud features are either disabled for the environment or not configured.
        const message = "Cloud Sync is disabled in this environment or not configured. To enable it, deploy the app to a GitHub Pages URL and follow the README instructions.";
        setCloud((c) => ({ ...c, signedIn: false, message: `✋ ${message}` }));
        return;
    }

    const login = await pca.loginPopup({ scopes: GRAPH_SCOPES });
    const account = login.account;
    const tokenResp = await pca
      .acquireTokenSilent({ scopes: GRAPH_SCOPES, account })
      .catch(() => pca.acquireTokenPopup({ scopes: GRAPH_SCOPES }));
    const accessToken = tokenResp.accessToken as string;
    setCloud({ ready: true, signedIn: true, account, accessToken, message: "Signed in successfully. Fetching live data..." });
  } catch (e: any) {
    // FIX: Add specific handling for the 'interaction_in_progress' error to provide clearer user feedback.
    // This catches the specific error reported and prevents an unhandled exception, improving sign-in robustness.
    if (e.errorCode === 'interaction_in_progress' || (e.message && e.message.includes('interaction_in_progress'))) {
        setCloud((c) => ({ ...c, signedIn: false, message: "Sign-in popup is already open. Please complete the sign-in in the other window or try again." }));
    } else {
        setCloud((c) => ({ ...c, signedIn: false, message: `Sign-in failed: ${e && e.message ? e.message : String(e)}` }));
    }
  }
}

export async function msalSilentSignIn(): Promise<{accessToken: string, account: any} | null> {
    try {
        const pca = await getMsalInstance();
        if (!pca) return null;

        const account = pca.getAllAccounts()[0];
        if (!account) return null;

        const tokenResp = await pca.acquireTokenSilent({ scopes: GRAPH_SCOPES, account });
        return { accessToken: tokenResp.accessToken, account };
    } catch (error) {
        // Silent sign-in failures are expected if a user needs to login interactively, so we just log it as a warning.
        console.warn("Silent sign-in failed:", error);
        return null;
    }
}