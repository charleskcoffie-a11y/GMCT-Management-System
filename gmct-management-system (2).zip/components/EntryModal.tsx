// components/EntryModal.tsx
import React, { useState, useEffect, useMemo } from 'react';
import type { Entry, EntryType, Method, Member, Settings } from '../types';
import { sanitizeEntry } from '../utils';

interface EntryModalProps {
    entry: Entry | null;
    members: Member[];
    settings: Settings;
    onSave: (entry: Entry) => void;
    onSaveAndNew: (entry: Entry) => void;
    onClose: () => void;
    onDelete: (id: string) => void;
}

const EntryModal: React.FC<EntryModalProps> = ({ entry, members, settings, onSave, onSaveAndNew, onClose, onDelete }) => {
    const [formData, setFormData] = useState<Entry>(entry || sanitizeEntry({}));
    const [amountInput, setAmountInput] = useState<string>('');
    const [classFilter, setClassFilter] = useState('all');

    useEffect(() => {
        const initialData = entry || sanitizeEntry({});
        setFormData(initialData);
        setAmountInput(entry ? String(entry.amount) : '');
    }, [entry]);

    const filteredMembers = useMemo(() => {
        if (classFilter === 'all') {
            return members;
        }
        return members.filter(m => m.classNumber === classFilter);
    }, [members, classFilter]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        if (value === '' || /^\d*\.?\d{0,2}$/.test(value)) {
            setAmountInput(value);
            setFormData(prev => ({ ...prev, amount: parseFloat(value) || 0 }));
        }
    };
    
    const handleMemberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const memberName = e.target.value;
        const selectedMember = members.find(m => m.name === memberName);
        setFormData(prev => ({
            ...prev,
            memberName: memberName,
            memberID: selectedMember ? selectedMember.id : ''
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.amount < 1) {
            alert("Minimum amount is $1.00. Please enter a valid amount.");
            return;
        }
        onSave(formData);
    };
    
    const handleSubmitAndNew = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.memberName) {
            alert("Please select a member.");
            return;
        }
        if (formData.amount < 1) {
            alert("Minimum amount is $1.00. Please enter a valid amount.");
            return;
        }
        onSaveAndNew(formData);
        setFormData(prev => sanitizeEntry({ date: prev.date }));
        setAmountInput('');
    };
    
    const clearAmount = () => {
        setAmountInput('');
        setFormData(p => ({ ...p, amount: 0 }));
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 border-b">
                        <h2 className="text-xl font-bold text-gray-800">{entry ? 'Edit Entry' : 'Add New Entry'}</h2>
                    </div>
                    <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                        {/* Member Filter and Name */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="classFilter" className="block font-medium text-gray-700">Filter by Class</label>
                                <select 
                                    id="classFilter" 
                                    value={classFilter} 
                                    onChange={e => setClassFilter(e.target.value)}
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                >
                                    <option value="all">All Classes</option>
                                    {Array.from({ length: settings.maxClasses }, (_, i) => String(i + 1)).map(num => (
                                        <option key={num} value={num}>Class {num}</option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="memberName" className="block font-medium text-gray-700">Member Name</label>
                                <input
                                    id="memberName"
                                    name="memberName"
                                    type="text"
                                    list="members-list"
                                    value={formData.memberName}
                                    onChange={handleMemberChange}
                                    required
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                />
                                <datalist id="members-list">
                                    {filteredMembers.map(m => <option key={m.id} value={m.name} />)}
                                </datalist>
                            </div>
                        </div>
                        {/* Date and Amount */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="date" className="block font-medium text-gray-700">Date</label>
                                <input type="date" name="date" value={formData.date} onChange={handleChange} required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                            </div>
                            <div>
                                <label htmlFor="amount" className="block font-medium text-gray-700">Amount</label>
                                <div className="mt-1 relative">
                                    <input type="text" inputMode="decimal" placeholder="0.00" name="amount" value={amountInput} onChange={handleAmountChange} required className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 pr-10 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                                     <button type="button" onClick={clearAmount} className="absolute inset-y-0 right-0 px-3 flex items-center text-gray-400 hover:text-gray-600" aria-label="Clear amount">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        {/* Type and Method */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="type" className="block font-medium text-gray-700">Type</label>
                                <select name="type" value={formData.type} onChange={handleChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                    {(["tithe", "offering", "first-fruit", "pledge", "harvest-levy", "other"] as EntryType[]).map(t => <option key={t} value={t}>{t.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</option>)}
                                </select>
                            </div>
                             <div>
                                <label htmlFor="method" className="block font-medium text-gray-700">Method</label>
                                <select name="method" value={formData.method} onChange={handleChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                    {(["cash", "check", "card", "e-transfer", "mobile", "other"] as Method[]).map(m => <option key={m} value={m}>{m.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</option>)}
                                </select>
                            </div>
                        </div>
                        {/* Fund and Note */}
                         <div>
                            <label htmlFor="fund" className="block font-medium text-gray-700">Fund</label>
                            <input type="text" name="fund" value={formData.fund} onChange={handleChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                         <div>
                            <label htmlFor="note" className="block font-medium text-gray-700">Note</label>
                            <textarea name="note" value={formData.note || ''} onChange={handleChange} rows={2} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"></textarea>
                        </div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-b-lg flex justify-between items-center">
                        <div>
                            {entry && (
                                <button type="button" onClick={() => onDelete(entry.id)} className="text-red-600 hover:text-red-800 font-medium">Delete</button>
                            )}
                        </div>
                        <div className="flex gap-2">
                             <button type="button" onClick={onClose} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg">Cancel</button>
                             {!entry && (
                                <button type="button" onClick={handleSubmitAndNew} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg">Save & Add Another</button>
                             )}
                             <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg">Save Entry</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default EntryModal;