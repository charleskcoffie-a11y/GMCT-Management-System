// components/Settings.tsx
import React, { useState, useEffect } from 'react';
import type { Settings, CloudState } from '../types';
import { msalSignIn } from '../services/oneDrive';
import { testSharePointConnection } from '../services/sharepoint';

interface SettingsProps {
    settings: Settings;
    setSettings: React.Dispatch<React.SetStateAction<Settings>>;
    cloud: CloudState;
    setCloud: React.Dispatch<React.SetStateAction<CloudState>>;
    onExport: (format: 'json_all') => void;
    onImport: (file: File) => void;
}

const SettingsTab: React.FC<SettingsProps> = ({ settings, setSettings, cloud, setCloud, onExport, onImport }) => {
    const [localSettings, setLocalSettings] = useState<Settings>(settings);
    const [testResult, setTestResult] = useState<{success: boolean, message: string} | null>(null);

    // Detect if the app is running in a configured production environment (GitHub Pages).
    // Cloud Sync features are only enabled in this environment to prevent Redirect URI errors.
    const isProdEnvironment = window.location.hostname.includes('github.io');

    useEffect(() => {
        setLocalSettings(settings);
    }, [settings]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type, checked } = e.target as HTMLInputElement;
        setLocalSettings(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : type === 'number' ? parseInt(value, 10) : value
        }));
    };

    const handleSave = () => {
        setSettings(localSettings);
        alert('Settings saved!');
    };

    const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            onImport(file);
        }
        event.target.value = ""; // Reset file input
    };

    const handleTestConnection = async () => {
        if (!cloud.accessToken) {
            alert("Please sign in to test the connection.");
            return;
        }
        const result = await testSharePointConnection(cloud.accessToken);
        setTestResult(result);
    }

    return (
        <div className="space-y-8 max-w-3xl">
            {/* General Settings */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200/80">
                <h3 className="text-xl font-bold text-slate-800 border-b pb-3 mb-4">General Settings</h3>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="currency" className="block font-medium text-slate-700">Currency Symbol</label>
                        <input type="text" id="currency" name="currency" value={localSettings.currency} onChange={handleChange} className="mt-1 block w-full md:w-1/2 border-slate-300 rounded-md shadow-sm" />
                    </div>
                    <div>
                        <label htmlFor="maxClasses" className="block font-medium text-slate-700">Number of Classes</label>
                        <input type="number" id="maxClasses" name="maxClasses" value={localSettings.maxClasses} onChange={handleChange} className="mt-1 block w-full md:w-1/2 border-slate-300 rounded-md shadow-sm" />
                    </div>
                     <div className="flex items-center gap-3">
                        <input type="checkbox" id="enforceDirectory" name="enforceDirectory" checked={localSettings.enforceDirectory} onChange={handleChange} className="h-4 w-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500" />
                        <label htmlFor="enforceDirectory" className="font-medium text-slate-700">Enforce Member Directory for new entries</label>
                    </div>
                </div>
                <div className="mt-6 text-right">
                    <button onClick={handleSave} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg">Save Settings</button>
                </div>
            </div>
            
             {/* Cloud Sync */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200/80">
                <h3 className="text-xl font-bold text-slate-800 border-b pb-3 mb-4">Cloud Sync (OneDrive & SharePoint)</h3>
                {!isProdEnvironment ? (
                     <div className="text-center p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <h4 className="font-bold text-yellow-800">Cloud Sync is Disabled in this Environment</h4>
                        <p className="text-yellow-700 mt-2">
                            Microsoft sign-in only works on the deployed GitHub Pages website. This is expected behavior for development and preview environments.
                        </p>
                        <p className="text-yellow-700 mt-2">
                            To enable cloud features, please follow the deployment instructions in the <strong>README.md</strong> file.
                        </p>
                    </div>
                ) : !cloud.signedIn ? (
                     <div className="text-center">
                        <p className="text-slate-600 mb-4">Sign in with your Microsoft account to enable cloud sync and live data features.</p>
                        <button onClick={() => msalSignIn(setCloud)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg">
                            Sign in with Microsoft
                        </button>
                     </div>
                ) : (
                    <div className="space-y-4">
                        <p className="text-green-700 bg-green-100 p-3 rounded-md">Signed in as: <strong>{cloud.account?.name}</strong></p>
                        <button onClick={handleTestConnection} className="bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg">Test SharePoint Connection</button>
                        {testResult && (
                             <p className={`p-3 rounded-md ${testResult.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{testResult.message}</p>
                        )}
                    </div>
                )}
                 {cloud.message && isProdEnvironment && <p className="mt-4 text-sm text-slate-500 text-center">{cloud.message}</p>}
            </div>


            {/* Data Management */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200/80">
                <h3 className="text-xl font-bold text-slate-800 border-b pb-3 mb-4">Data Backup & Restore</h3>
                <div className="flex flex-col md:flex-row gap-4 items-start">
                    <div className="flex-1">
                        <h4 className="font-semibold text-slate-700">Backup All Data</h4>
                        <p className="text-sm text-slate-500 mb-2">Save a single JSON file containing all entries, members, users, and settings.</p>
                        <button onClick={() => onExport('json_all')} className="bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg">
                            Export All Data
                        </button>
                    </div>
                    <div className="flex-1">
                        <h4 className="font-semibold text-slate-700">Restore from Backup</h4>
                        <p className="text-sm text-slate-500 mb-2">Restore data from a previously saved JSON backup file. This will overwrite existing data.</p>
                        <label className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-lg cursor-pointer inline-block">
                           <span>Import from Backup</span>
                           <input type="file" accept=".json" className="hidden" onChange={handleFileImport} />
                        </label>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default SettingsTab;