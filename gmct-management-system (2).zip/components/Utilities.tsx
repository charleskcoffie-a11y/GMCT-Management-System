// components/Utilities.tsx
import React, { useState, useMemo } from 'react';
import type { Entry, Member, Settings, EntryType } from '../types';
import { toCsv, sanitizeString } from '../utils';

interface UtilitiesProps {
    entries: Entry[];
    members: Member[];
    settings: Settings;
}

const Utilities: React.FC<UtilitiesProps> = ({ entries, members, settings }) => {
    const today = new Date().toISOString().slice(0, 10);
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState(today);
    const [emailTo, setEmailTo] = useState('');

    const entryTypes = useMemo(() => Array.from(new Set(entries.map(e => e.type))), [entries]);
    const classNumbers = useMemo(() => ['all', ...Array.from({ length: settings.maxClasses }, (_, i) => String(i + 1))], [settings.maxClasses]);
    
    const [selectedTypes, setSelectedTypes] = useState<Set<EntryType | 'all'>>(new Set(['all']));
    const [selectedClasses, setSelectedClasses] = useState<Set<string>>(new Set(['all']));

    const handleTypeChange = (type: EntryType | 'all') => {
        const newSelection = new Set(selectedTypes);
        if (type === 'all') {
            newSelection.clear();
            newSelection.add('all');
        } else {
            newSelection.delete('all');
            if (newSelection.has(type)) {
                newSelection.delete(type);
            } else {
                newSelection.add(type);
            }
            if(newSelection.size === 0 || newSelection.size === entryTypes.length) {
                 newSelection.clear();
                 newSelection.add('all');
            }
        }
        setSelectedTypes(newSelection);
    };

     const handleClassChange = (cls: string) => {
        const newSelection = new Set(selectedClasses);
        if (cls === 'all') {
            newSelection.clear();
            newSelection.add('all');
        } else {
            newSelection.delete('all');
            if (newSelection.has(cls)) {
                newSelection.delete(cls);
            } else {
                newSelection.add(cls);
            }
            if(newSelection.size === 0 || newSelection.size === classNumbers.length - 1) {
                newSelection.clear();
                newSelection.add('all');
            }
        }
        setSelectedClasses(newSelection);
    };

    const membersById = useMemo(() => new Map(members.map(m => [m.id, m])), [members]);

    const filteredEntries = useMemo(() => {
        return entries.filter(entry => {
            if (startDate && entry.date < startDate) return false;
            if (endDate && entry.date > endDate) return false;
            
            if (!selectedTypes.has('all') && !selectedTypes.has(entry.type)) {
                return false;
            }

            const member = membersById.get(entry.memberID);
            if (!selectedClasses.has('all') && (!member || !member.classNumber || !selectedClasses.has(member.classNumber))) {
                return false;
            }

            return true;
        });
    }, [entries, startDate, endDate, selectedTypes, selectedClasses, membersById]);
    
    const generateAndDownloadCsv = () => {
        if (filteredEntries.length === 0) {
            alert("No entries found for the selected filters. Nothing to export.");
            return false;
        }

        const reportData = filteredEntries.map(entry => {
            const member = membersById.get(entry.memberID);
            return {
                MemberName: sanitizeString(entry.memberName),
                MemberID: sanitizeString(entry.memberID).substring(0, 8),
                ClassNumber: member ? sanitizeString(member.classNumber) : 'N/A',
                Date: entry.date,
                Type: entry.type,
                Fund: entry.fund,
                Amount: entry.amount.toFixed(2),
                Method: entry.method,
                Note: sanitizeString(entry.note),
            };
        });

        const csv = toCsv(reportData);
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        const filename = `Donation_Report_${startDate || 'start'}_to_${endDate}.csv`;
        link.download = filename;
        link.click();
        URL.revokeObjectURL(link.href);
        return true;
    };
    
     const handleEmailReport = () => {
        if (!emailTo) {
            alert("Please enter a recipient's email address.");
            return;
        }
        const success = generateAndDownloadCsv();
        if (success) {
            const subject = "Donation Report";
            const body = `Hello,

Please find the generated donation report attached.

(Note: You must MANUALLY ATTACH the file that was just downloaded to your computer. The file is named 'Donation_Report_...csv' and should be in your 'Downloads' folder.)

Thank you.`;
            window.location.href = `mailto:${emailTo}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        }
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">Utilities</h2>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200/80 space-y-6">
                <h3 className="text-xl font-bold text-slate-800 border-b pb-3 mb-4">Donation Report Generator</h3>
                
                {/* Filters */}
                <div className="space-y-4">
                    {/* Date Range */}
                    <fieldset>
                        <legend className="font-semibold text-slate-700 mb-2">Date Range</legend>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="startDate" className="block text-sm font-medium text-slate-600">Start Date</label>
                                <input type="date" id="startDate" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 block w-full border-slate-300 rounded-md shadow-sm"/>
                            </div>
                            <div>
                                <label htmlFor="endDate" className="block text-sm font-medium text-slate-600">End Date</label>
                                <input type="date" id="endDate" value={endDate} onChange={e => setEndDate(e.target.value)} className="mt-1 block w-full border-slate-300 rounded-md shadow-sm"/>
                            </div>
                        </div>
                    </fieldset>

                    {/* Categories */}
                    <fieldset>
                         <legend className="font-semibold text-slate-700 mb-2">Contribution Type</legend>
                         <div className="flex flex-wrap gap-2">
                             <div className="flex items-center">
                                <input type="checkbox" id="type-all" checked={selectedTypes.has('all')} onChange={() => handleTypeChange('all')} className="h-4 w-4 text-indigo-600 border-slate-300 rounded"/>
                                <label htmlFor="type-all" className="ml-2 text-slate-700">All Categories</label>
                             </div>
                             {entryTypes.map(type => (
                                 <div key={type} className="flex items-center">
                                    <input type="checkbox" id={`type-${type}`} checked={selectedTypes.has(type)} onChange={() => handleTypeChange(type)} className="h-4 w-4 text-indigo-600 border-slate-300 rounded" disabled={selectedTypes.has('all')} />
                                    <label htmlFor={`type-${type}`} className="ml-2 text-slate-700 capitalize">{type.replace('-', ' ')}</label>
                                 </div>
                             ))}
                         </div>
                    </fieldset>

                    {/* Classes */}
                    <fieldset>
                        <legend className="font-semibold text-slate-700 mb-2">Member Class</legend>
                        <div className="flex flex-wrap gap-2">
                            <div className="flex items-center">
                                <input type="checkbox" id="class-all" checked={selectedClasses.has('all')} onChange={() => handleClassChange('all')} className="h-4 w-4 text-indigo-600 border-slate-300 rounded"/>
                                <label htmlFor="class-all" className="ml-2 text-slate-700">All Classes</label>
                            </div>
                            {classNumbers.slice(1).map(cls => (
                                <div key={cls} className="flex items-center">
                                    <input type="checkbox" id={`class-${cls}`} checked={selectedClasses.has(cls)} onChange={() => handleClassChange(cls)} className="h-4 w-4 text-indigo-600 border-slate-300 rounded" disabled={selectedClasses.has('all')} />
                                    <label htmlFor={`class-${cls}`} className="ml-2 text-slate-700">Class {cls}</label>
                                </div>
                            ))}
                        </div>
                    </fieldset>
                </div>

                {/* Actions */}
                <div className="border-t pt-6 space-y-4">
                     <div>
                        <button onClick={generateAndDownloadCsv} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg w-full md:w-auto">
                            Generate & Download CSV
                        </button>
                        <p className="text-sm text-slate-500 mt-1">{filteredEntries.length.toLocaleString()} entries match your filters.</p>
                     </div>
                     <div className="flex flex-col md:flex-row gap-2">
                         <input
                            type="email"
                            placeholder="Recipient's email address"
                            value={emailTo}
                            onChange={e => setEmailTo(e.target.value)}
                            className="block w-full border-slate-300 rounded-md shadow-sm"
                        />
                        <button onClick={handleEmailReport} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg flex-shrink-0">
                           Download &amp; Prepare Email
                        </button>
                     </div>
                </div>

            </div>

             {/* Danger Zone */}
            <div className="bg-red-50 p-6 rounded-xl border border-red-200">
                <h3 className="text-xl font-bold text-red-800">Danger Zone</h3>
                <p className="text-red-700 mt-1">These actions are permanent and cannot be undone.</p>
                <div className="mt-4">
                    <button 
                        onClick={() => {
                            if (window.confirm("Are you sure you want to clear ALL local data? This will not affect your cloud data but will log you out.")) {
                                localStorage.clear();
                                window.location.reload();
                            }
                        }}
                        className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg"
                    >
                        Clear All Local Data
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Utilities;
