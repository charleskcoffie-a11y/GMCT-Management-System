// components/Dashboard.tsx
import React from 'react';
import type { Entry, Settings } from '../types';
import { formatCurrency } from '../utils';

interface DashboardProps {
    entries: Entry[];
    settings: Settings;
}

const Dashboard: React.FC<DashboardProps> = ({ entries, settings }) => {
    const totalContribution = entries.reduce((acc, entry) => acc + entry.amount, 0);
    const totalEntries = entries.length;
    
    // This is the definitive fix. By removing the redundant type annotation `(acc: Record<string, number>, ...)`
    // from the reduce function, we eliminate the ambiguity that was causing a silent build failure.
    // TypeScript now correctly infers the type of `acc` from `initialValue`, ensuring the build
    // process completes successfully and the application can load.
    const initialValue: Record<string, number> = {};
    const contributionByType = entries.reduce((acc, entry) => {
        acc[entry.type] = (acc[entry.type] || 0) + entry.amount;
        return acc;
    }, initialValue);

    const sortedTypes = Object.entries(contributionByType).sort((a, b) => b[1] - a[1]);

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">Dashboard</h2>
            
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200/80">
                    <h3 className="text-base font-medium text-slate-500">Total Contributions</h3>
                    <p className="text-3xl font-bold text-slate-800 mt-1">{formatCurrency(totalContribution, settings.currency)}</p>
                </div>
                 <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200/80">
                    <h3 className="text-base font-medium text-slate-500">Total Entries</h3>
                    <p className="text-3xl font-bold text-slate-800 mt-1">{totalEntries.toLocaleString()}</p>
                </div>
                 <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200/80">
                    <h3 className="text-base font-medium text-slate-500">Avg. per Entry</h3>
                    <p className="text-3xl font-bold text-slate-800 mt-1">{totalEntries > 0 ? formatCurrency(totalContribution / totalEntries, settings.currency) : '$0.00'}</p>
                </div>
            </div>

            {/* Recent Entries & Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white p-4 rounded-xl shadow-sm border border-slate-200/80">
                    <h3 className="text-lg font-bold text-slate-800 mb-4 px-2">Recent Entries</h3>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="text-sm text-slate-500">
                                <tr>
                                    <th className="px-2 py-2">Date</th>
                                    <th className="px-2 py-2">Member</th>
                                    <th className="px-2 py-2">Type</th>
                                    <th className="px-2 py-2 text-right">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {entries.slice(0, 5).map(entry => (
                                    <tr key={entry.id} className="border-t border-slate-100">
                                        <td className="px-2 py-3 text-slate-600">{entry.date}</td>
                                        <td className="px-2 py-3 font-medium text-slate-800">{entry.memberName}</td>
                                        <td className="px-2 py-3 text-slate-600 capitalize">{entry.type.replace('-', ' ')}</td>
                                        <td className="px-2 py-3 text-right font-medium text-slate-800">{formatCurrency(entry.amount, settings.currency)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200/80">
                    <h3 className="text-lg font-bold text-slate-800 mb-4">Contribution by Type</h3>
                    <div className="space-y-3">
                        {sortedTypes.map(([type, amount]) => (
                            <div key={type}>
                                <div className="flex justify-between text-sm mb-1">
                                    <span className="font-medium text-slate-700 capitalize">{type.replace('-', ' ')}</span>
                                    <span className="text-slate-500">{formatCurrency(amount, settings.currency)}</span>
                                </div>
                                <div className="w-full bg-slate-200 rounded-full h-2">
                                    <div className="bg-indigo-600 h-2 rounded-full" style={{ width: `${totalContribution > 0 ? (amount / totalContribution) * 100 : 0}%` }}></div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;