// components/Members.tsx
import React, { useState, useMemo } from 'react';
import type { Member, Settings } from '../types';
import { sanitizeString, sanitizeMember, fromCsv } from '../utils';
import MemberModal from './MemberModal';
import { UploadIcon } from './icons';

interface MembersProps {
    members: Member[];
    setMembers: React.Dispatch<React.SetStateAction<Member[]>>;
    settings: Settings;
}

const Members: React.FC<MembersProps> = ({ members, setMembers, settings }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedMember, setSelectedMember] = useState<Member | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [classFilter, setClassFilter] = useState<string>('all');

    const classOptions = useMemo(() => {
        return ['all', ...Array.from({ length: settings.maxClasses }, (_, i) => String(i + 1))];
    }, [settings.maxClasses]);

    const handleImportMembers = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = () => {
            try {
                const rows = fromCsv(String(reader.result));
                const importedMembers: Member[] = rows
                    .map(r => sanitizeMember(r))
                    .filter(m => m.name && m.name !== "Unnamed Member");

                if (importedMembers.length === 0) {
                    alert("No valid members to import were found in the file.");
                    return;
                }

                // Check for duplicates based on name (case-insensitive)
                const existingMemberNames = new Set(
                    members.map(m => sanitizeString(m.name).toLowerCase())
                );

                const newMembers: Member[] = [];
                let duplicateCount = 0;

                importedMembers.forEach(member => {
                    const key = sanitizeString(member.name).toLowerCase();
                    if (existingMemberNames.has(key)) {
                        duplicateCount++;
                    } else {
                        newMembers.push(member);
                        existingMemberNames.add(key); // Add to set to handle duplicates within the CSV itself
                    }
                });
                
                if (newMembers.length > 0) {
                    setMembers(prev => [...prev, ...newMembers].sort((a, b) => a.name.localeCompare(b.name)));
                }

                const message = `
Import Complete
- Processed: ${importedMembers.length} valid rows from file.
- Added: ${newMembers.length} new members.
- Skipped: ${duplicateCount} duplicate members (based on name).
                `.trim();

                alert(message);

            } catch (e) {
                console.error("Member CSV Import Error:", e);
                alert("Failed to import CSV. Please check the file format. It should have 'name' and 'classNumber' headers.");
            }
        };
        reader.readAsText(file);
        event.target.value = ""; // Reset file input
    };

    const handleSave = (member: Member) => {
        const newMembers = [...members];
        const index = newMembers.findIndex(m => m.id === member.id);

        if (index > -1) { // Edit
            newMembers[index] = member;
        } else { // Add
            newMembers.push(member);
        }
        setMembers(newMembers.sort((a,b) => a.name.localeCompare(b.name)));
        setIsModalOpen(false);
    };
    
    const handleDelete = (id: string) => {
        if (window.confirm("Are you sure you want to delete this member? This cannot be undone.")) {
            setMembers(members.filter(m => m.id !== id));
        }
    };
    
    const filteredMembers = members.filter(m => {
        const searchTermMatch = 
            m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            m.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
            m.classNumber?.toLowerCase().includes(searchTerm.toLowerCase());
        
        const classFilterMatch = classFilter === 'all' || m.classNumber === classFilter;

        return searchTermMatch && classFilterMatch;
    });

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-2xl font-bold text-slate-800">Member Directory</h2>
                <div className="flex items-center gap-2 w-full md:w-auto flex-wrap justify-end">
                    <input 
                        type="text"
                        placeholder="Search members..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="border border-slate-300 rounded-lg py-2 px-3 w-full md:w-auto"
                    />
                    <select
                        value={classFilter}
                        onChange={e => setClassFilter(e.target.value)}
                        className="border border-slate-300 rounded-lg py-2 px-3 w-full md:w-auto"
                    >
                        {classOptions.map(cls => (
                            <option key={cls} value={cls}>
                                {cls === 'all' ? 'All Classes' : `Class ${cls}`}
                            </option>
                        ))}
                    </select>
                     <label className="bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg cursor-pointer inline-flex items-center gap-2 transition-colors duration-200">
                        <UploadIcon />
                        <span>Import Members</span>
                        <input type="file" accept=".csv" className="hidden" onChange={handleImportMembers} />
                    </label>
                    <button onClick={() => { setSelectedMember(null); setIsModalOpen(true); }} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex-shrink-0">
                        Add Member
                    </button>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200/80 overflow-x-auto">
                <table className="w-full text-left text-slate-500">
                    <thead className="text-base text-slate-700 uppercase bg-slate-50">
                        <tr>
                            <th className="px-6 py-3">Member ID</th>
                            <th className="px-6 py-3">Name</th>
                            <th className="px-6 py-3">Class #</th>
                            <th className="px-6 py-3"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredMembers.map(member => (
                            <tr key={member.id} className="bg-white border-b hover:bg-slate-50">
                                <td className="px-6 py-4 text-sm font-mono text-slate-500">{member.id.substring(0, 8)}</td>
                                <td className="px-6 py-4 font-medium text-slate-900">{sanitizeString(member.name)}</td>
                                <td className="px-6 py-4">{sanitizeString(member.classNumber) || 'N/A'}</td>
                                <td className="px-6 py-4 text-right">
                                    <button onClick={() => { setSelectedMember(member); setIsModalOpen(true); }} className="font-medium text-indigo-600 hover:underline mr-4">Edit</button>
                                    <button onClick={() => handleDelete(member.id)} className="font-medium text-red-600 hover:text-red-800 hover:underline">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {isModalOpen && <MemberModal member={selectedMember} onSave={handleSave} onClose={() => setIsModalOpen(false)} />}
        </div>
    );
};

export default Members;
