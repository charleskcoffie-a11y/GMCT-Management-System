import React, { useState, useMemo, useEffect } from 'react';
import type { Member, AttendanceRecord, AttendanceStatus, User, Settings } from '../types';
import { sanitizeAttendanceStatus, sanitizeString } from '../utils';

interface AttendanceProps {
    members: Member[];
    attendance: AttendanceRecord[];
    setAttendance: React.Dispatch<React.SetStateAction<AttendanceRecord[]>>;
    currentUser: User;
    settings: Settings;
}

const Attendance: React.FC<AttendanceProps> = ({ members, attendance, setAttendance, currentUser, settings }) => {
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
    const [classFilter, setClassFilter] = useState<string>('all');
    const [pendingChanges, setPendingChanges] = useState<Map<string, AttendanceStatus>>(new Map());

    // Reset pending changes when date or filter changes
    useEffect(() => {
        setPendingChanges(new Map());
    }, [selectedDate, classFilter]);
    
    const classOptions = useMemo(() => {
        return ['all', ...Array.from({ length: settings.maxClasses }, (_, i) => String(i + 1))];
    }, [settings.maxClasses]);

    const filteredMembers = useMemo(() => {
        if (currentUser.role !== 'admin' || classFilter === 'all') {
            return members;
        }
        return members.filter(m => m.classNumber === classFilter);
    }, [members, classFilter, currentUser.role]);

    const getStatusForMember = (memberId: string): AttendanceStatus => {
        // Show pending change if it exists
        if (pendingChanges.has(memberId)) {
            return pendingChanges.get(memberId)!;
        }
        // Otherwise, show the saved status
        const record = attendance.find(r => r.date === selectedDate);
        const status = record?.records.find(mr => mr.memberId === memberId)?.status;
        return sanitizeAttendanceStatus(status);
    };

    const handleStatusChange = (memberId: string, status: AttendanceStatus) => {
        const newChanges = new Map(pendingChanges);
        newChanges.set(memberId, status);
        setPendingChanges(newChanges);
    };
    
    const handleSave = () => {
        if (pendingChanges.size === 0) {
            alert("No changes to save.");
            return;
        }

        const existingRecord = attendance.find(r => r.date === selectedDate);
        const confirmationMessage = existingRecord
            ? "Attendance for this date already exists. Overwrite with your changes?"
            : "Are you sure you want to save this attendance record?";

        if (window.confirm(confirmationMessage)) {
            const newAttendance = [...attendance.filter(r => r.date !== selectedDate)]; // Remove old record for this date
            let recordForDate = existingRecord ? { ...existingRecord, records: [...existingRecord.records] } : { date: selectedDate, records: [] };

            pendingChanges.forEach((status, memberId) => {
                const memberRecordIndex = recordForDate.records.findIndex(mr => mr.memberId === memberId);
                if (memberRecordIndex > -1) {
                    recordForDate.records[memberRecordIndex].status = status;
                } else {
                    recordForDate.records.push({ memberId, status });
                }
            });

            newAttendance.push(recordForDate);
            setAttendance(newAttendance);
            setPendingChanges(new Map());
            alert("Attendance saved successfully!");
        }
    };

    const STATUS_OPTIONS: { value: AttendanceStatus, label: string }[] = [
        { value: 'present', label: 'Present' },
        { value: 'absent', label: 'Absent' },
        { value: 'sick', label: 'Sick' },
        { value: 'travel', label: 'Travel' },
        { value: 'catechumen', label: 'Catechumen' },
    ];

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">Class Attendance</h2>
            
            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200/80 flex flex-wrap items-center gap-4">
                <div>
                    <label className="block font-medium text-slate-700 mb-1">Select Date</label>
                    <input
                        type="date"
                        value={selectedDate}
                        onChange={e => setSelectedDate(e.target.value)}
                        className="border-slate-300 rounded-md"
                    />
                </div>
                 {currentUser.role === 'admin' && (
                    <div>
                        <label htmlFor="classFilter" className="block font-medium text-slate-700 mb-1">Filter by Class</label>
                        <select
                            id="classFilter"
                            value={classFilter}
                            onChange={e => setClassFilter(e.target.value)}
                            className="border-slate-300 rounded-md"
                        >
                            {classOptions.map(cls => (
                                <option key={cls} value={cls}>
                                    {cls === 'all' ? 'All Classes' : `Class ${cls}`}
                                </option>
                            ))}
                        </select>
                    </div>
                 )}
            </div>
            
             <div className="bg-white rounded-xl shadow-sm border border-slate-200/80 overflow-x-auto">
                 <div className="p-4 space-y-3">
                    {filteredMembers.map(member => (
                        <div key={member.id} className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-2 items-center p-3 rounded-lg bg-slate-50/50">
                            <span className="font-medium text-slate-800">{sanitizeString(member.name)}</span>
                            <div className="flex gap-2 flex-wrap">
                                {STATUS_OPTIONS.map(opt => (
                                     <button 
                                        key={opt.value}
                                        onClick={() => handleStatusChange(member.id, opt.value)}
                                        className={`px-3 py-1 font-medium rounded-full transition-colors text-sm ${
                                            getStatusForMember(member.id) === opt.value
                                                ? 'bg-indigo-600 text-white'
                                                : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                                        }`}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        </div>
                    ))}
                 </div>
            </div>
            <div className="sticky bottom-0 -mx-8 px-8 py-4 bg-white/80 backdrop-blur-sm border-t border-slate-200 flex justify-end">
                <button
                    onClick={handleSave}
                    disabled={pendingChanges.size === 0}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg disabled:bg-slate-400 disabled:cursor-not-allowed transition-colors"
                >
                    Save Attendance
                </button>
            </div>
        </div>
    );
};

export default Attendance;