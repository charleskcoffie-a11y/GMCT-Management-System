import React from 'react';
import { v4 as uuidv4 } from 'uuid';
import { fromCsv, sanitizeString, sanitizeEntry } from '../utils';
import type { Entry, User } from '../types';
import { ChurchIcon, DownloadIcon, UploadIcon, PrintIcon } from './icons';

interface HeaderProps {
    entries: Entry[];
    onImport: (entries: Entry[]) => void;
    onExport: (format: 'csv' | 'json') => void;
    currentUser: User | null;
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ entries, onImport, onExport, currentUser, onLogout }) => {
    const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
            try {
                const rows = fromCsv(String(reader.result));
                const importedEntries: Entry[] = rows
                    .map(r => sanitizeEntry(r))
                    .filter(e => e.amount > 0 && e.memberName !== "Unknown");

                if (importedEntries.length === 0) {
                    alert("No valid entries to import were found in the file.");
                    return;
                }

                const existingEntryKeys = new Set(
                    entries.map(e => `${e.date}|${sanitizeString(e.memberName)}|${e.amount}`)
                );

                const newEntries: Entry[] = [];
                let duplicateCount = 0;

                importedEntries.forEach(entry => {
                    const key = `${entry.date}|${sanitizeString(entry.memberName)}|${entry.amount}`;
                    if (existingEntryKeys.has(key)) {
                        duplicateCount++;
                    } else {
                        newEntries.push(entry);
                        existingEntryKeys.add(key);
                    }
                });

                if (newEntries.length > 0) {
                    onImport(newEntries);
                }
                
                const message = `
Import Complete
- Processed: ${importedEntries.length} valid rows from file.
- Added: ${newEntries.length} new records.
- Skipped: ${duplicateCount} duplicate records.
            `.trim();

                alert(message);
            } catch (e) {
                console.error("CSV Import Error:", e);
                alert("Failed to import CSV. Please check the file format.");
            }
        };
        reader.readAsText(file);
        event.target.value = ""; // Reset file input
    };

    return (
        <header className="bg-indigo-700 text-white rounded-xl p-4 mb-6 flex flex-col md:flex-row justify-between items-center gap-4 shadow-lg">
            <div className="flex items-center gap-4">
                <ChurchIcon />
                <div>
                    <h1 className="text-2xl font-bold">GMCT Management System</h1>
                    <p className="text-base text-indigo-200">Record Keeping Made Simple</p>
                </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap justify-center">
                 <label className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg cursor-pointer inline-flex items-center gap-2 transition-colors duration-200">
                    <UploadIcon />
                    <span>Import CSV</span>
                    <input type="file" accept=".csv" className="hidden" onChange={handleImportCSV} />
                </label>
                <button onClick={() => onExport('csv')} className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg inline-flex items-center gap-2 transition-colors duration-200">
                    <DownloadIcon />
                    <span>Export CSV</span>
                </button>
                <button onClick={() => onExport('json')} className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg inline-flex items-center gap-2 transition-colors duration-200">
                     <DownloadIcon />
                    <span>Export JSON</span>
                </button>
                <button onClick={() => window.print()} className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg inline-flex items-center gap-2 transition-colors duration-200">
                    <PrintIcon/>
                    <span>Print</span>
                </button>
                 {currentUser && (
                    <div className="flex items-center gap-2 border-l border-white/20 pl-2 ml-2">
                        <span className="text-base font-medium hidden sm:inline">Welcome, {sanitizeString(currentUser.username)}</span>
                        <button onClick={onLogout} className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-3 rounded-lg inline-flex items-center gap-2 transition-colors duration-200 text-sm">
                            Logout
                        </button>
                    </div>
                )}
            </div>
        </header>
    );
};

export default Header;