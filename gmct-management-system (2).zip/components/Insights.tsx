// components/Insights.tsx
import React from 'react';

const Insights: React.FC = () => {
    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">Insights</h2>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200/80 text-center">
                <h3 className="text-xl font-semibold text-slate-700">Coming Soon!</h3>
                <p className="text-slate-500 mt-2">Advanced analytics and visualizations will be available here in a future update.</p>
            </div>
        </div>
    );
};

export default Insights;
