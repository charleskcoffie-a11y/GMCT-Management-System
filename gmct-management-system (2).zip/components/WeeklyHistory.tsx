// components/WeeklyHistory.tsx
import React, { useState, useMemo, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { WeeklyHistoryRecord } from '../types';
import { sanitizeWeeklyHistoryRecord } from '../utils';

interface WeeklyHistoryProps {
    history: WeeklyHistoryRecord[];
    setHistory: React.Dispatch<React.SetStateAction<WeeklyHistoryRecord[]>>;
}

const initialFormState = (): WeeklyHistoryRecord => ({
    id: uuidv4(),
    dateOfService: new Date().toISOString().slice(0, 10),
    societyName: 'Ghana Methodist Church Toronto (GMCT)',
    officiant: '',
    liturgist: '',
    serviceTypes: [],
    serviceTypeOther: '',
    sermonTopic: '',
    worshipHighlights: '',
    announcementsBy: '',
    attendance: { men: 0, women: 0, junior: 0, adherents: 0, visitors: 0, catechumens: 0 },
    newMembersDetails: '',
    newMembersContact: '',
    specialDonationsDetails: '',
    events: '',
    observations: '',
    preparedBy: '',
});

const SOCIETY_NAMES = [
    "Ghana Methodist Church Toronto (GMCT)", "Holy Trinity Society, Montreal", "New Life International, Ottawa",
    "Bethel, Calgary", "Wesley, Edmonton", "Redemption, Toronto", "Ebenezer, Hamilton", "St. John’s, Newfoundland", "Peniel, Vancouver"
];

const SERVICE_TYPES = [
    "Divine Service", "Communion", "Youth Sunday", "Lay Movement / Wesley Hour",
    "Revival / Prayer Meeting", "Thanksgiving / Harvest", "Outreach / Evangelism"
];

// Reusable component for form input fields to reduce repetition and ensure consistency
// FIX: Replaced weak `any` prop types with a strict interface. This enforces that the `value`
// prop must be a string, preventing runtime crashes if a non-string value is passed.
interface FormInputProps {
    label: string;
    name: string;
    value: string;
    onChange: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement>;
    type?: string;
    required?: boolean;
    as?: 'input' | 'textarea';
    rows?: number;
}

const FormInput: React.FC<FormInputProps> = ({ label, name, value, onChange, type = "text", required = false, as = 'input', rows = 3 }) => {
    const commonProps = {
        id: name,
        name,
        value,
        onChange,
        required,
        className: "mt-1 block w-full border-gray-300 rounded-md shadow-sm bg-white text-base py-2 px-3 focus:border-indigo-500 focus:ring-indigo-500",
    };
    
    return (
        <div>
            <label htmlFor={name} className="block font-medium text-gray-700">{label}</label>
            {as === 'textarea'
                ? <textarea {...commonProps} rows={rows} />
                : <input {...commonProps} type={type} />
            }
        </div>
    );
};


const WeeklyHistory: React.FC<WeeklyHistoryProps> = ({ history, setHistory }) => {
    const [selectedRecordId, setSelectedRecordId] = useState<string | null>(null);
    const [formData, setFormData] = useState<WeeklyHistoryRecord>(initialFormState());

    useEffect(() => {
        if (selectedRecordId) {
            const record = history.find(h => h.id === selectedRecordId);
            if (record) setFormData(record);
        } else {
            setFormData(initialFormState());
        }
    }, [selectedRecordId, history]);
    
    const sortedHistory = useMemo(() => {
        return [...history].sort((a, b) => b.dateOfService.localeCompare(a.dateOfService));
    }, [history]);

    const totalAttendance = useMemo(() => {
        const { men, women, junior, adherents, visitors, catechumens } = formData.attendance;
        return men + women + junior + adherents + visitors + catechumens;
    }, [formData.attendance]);

    const handleSelectRecord = (id: string) => setSelectedRecordId(id);
    const handleAddNew = () => setSelectedRecordId(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        const [section, field] = name.split('.');

        if (field) { // Nested object
            setFormData(prev => ({ ...prev, [section]: { ...prev[section], [field]: value }}));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };

    const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        const [section, field] = name.split('.');
        const numValue = parseInt(value, 10) || 0;

        if (field) {
             setFormData(prev => ({ ...prev, [section]: { ...prev[section], [field]: numValue }}));
        }
    };
    
    const handleServiceTypeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { value, checked } = e.target;
        const currentTypes = formData.serviceTypes;
        const newTypes = checked ? [...currentTypes, value] : currentTypes.filter(t => t !== value);
        setFormData(prev => ({ ...prev, serviceTypes: newTypes }));
        // If "Other" is unchecked, clear the text field
        if (value === "Other" && !checked) {
             setFormData(prev => ({ ...prev, serviceTypes: newTypes, serviceTypeOther: '' }));
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const sanitized = sanitizeWeeklyHistoryRecord(formData);
        const index = history.findIndex(h => h.id === sanitized.id);
        const newHistory = [...history];
        if (index > -1) {
            newHistory[index] = sanitized;
        } else {
            newHistory.push(sanitized);
        }
        setHistory(newHistory);
        alert('Record saved successfully!');
        setSelectedRecordId(sanitized.id);
    };

    const handleDelete = () => {
        if (selectedRecordId && window.confirm("Are you sure you want to delete this record?")) {
            setHistory(history.filter(h => h.id !== selectedRecordId));
            setSelectedRecordId(null);
        }
    };
    
    const formSectionClasses = "p-6 rounded-xl border space-y-4";

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Record List */}
            <aside className="lg:col-span-1 space-y-4">
                <h2 className="text-2xl font-bold text-slate-800">History Records</h2>
                <div className="bg-white rounded-xl shadow-sm border border-slate-200/80 p-4">
                    <button onClick={handleAddNew} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg mb-4">
                        Add New Record
                    </button>
                    <ul className="space-y-2 max-h-[70vh] overflow-y-auto">
                        {sortedHistory.map(rec => (
                            <li key={rec.id}>
                                <button onClick={() => handleSelectRecord(rec.id)} className={`w-full text-left p-3 rounded-lg transition-colors ${selectedRecordId === rec.id ? 'bg-indigo-100 text-indigo-800' : 'hover:bg-slate-100'}`}>
                                    <p className="font-semibold">{rec.dateOfService}</p>
                                    <p className="text-sm text-slate-600">{rec.societyName}</p>
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
            </aside>

            {/* Right Column: Form */}
            <section className="lg:col-span-2">
                 <form onSubmit={handleSubmit} className="space-y-6">
                     <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200/80 space-y-6">
                        <h2 className="text-2xl font-bold text-slate-800">{selectedRecordId ? 'Edit Record' : 'New Record'}</h2>
                        
                        {/* Section 1: Basic Details */}
                        <div className={`${formSectionClasses} bg-slate-50`}>
                            <h3 className="text-lg font-semibold text-slate-700 -mt-2 mb-2">Basic Details</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="dateOfService" className="block font-medium text-gray-700">Date of Service</label>
                                    <input type="date" name="dateOfService" value={formData.dateOfService} onChange={handleChange} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm bg-white text-base py-2 px-3 focus:border-indigo-500 focus:ring-indigo-500"/>
                                </div>
                                 <div>
                                    <label htmlFor="societyName" className="block font-medium text-gray-700">Society Name</label>
                                    <select name="societyName" value={formData.societyName} onChange={handleChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm bg-white text-base py-2 px-3 focus:border-indigo-500 focus:ring-indigo-500">
                                        {SOCIETY_NAMES.map(name => <option key={name} value={name}>{name}</option>)}
                                    </select>
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                               <FormInput label="Minister / Officiant" name="officiant" value={formData.officiant} onChange={handleChange} />
                               <FormInput label="Liturgist" name="liturgist" value={formData.liturgist} onChange={handleChange} />
                            </div>
                            <div>
                                <label className="block font-medium text-gray-700">Service Type (select all that apply)</label>
                                <div className="mt-2 grid grid-cols-2 md:grid-cols-3 gap-2 text-base">
                                    {SERVICE_TYPES.map(type => (
                                        <div key={type} className="flex items-center p-2 bg-white rounded-md">
                                            <input type="checkbox" id={type} value={type} checked={formData.serviceTypes.includes(type)} onChange={handleServiceTypeChange} className="h-4 w-4 text-indigo-600 rounded"/>
                                            <label htmlFor={type} className="ml-2">{type}</label>
                                        </div>
                                    ))}
                                    <div className="flex items-center p-2 bg-white rounded-md">
                                        <input type="checkbox" id="Other" value="Other" checked={formData.serviceTypes.includes('Other')} onChange={handleServiceTypeChange} className="h-4 w-4 text-indigo-600 rounded"/>
                                        <label htmlFor="Other" className="ml-2">Other</label>
                                    </div>
                                </div>
                                {formData.serviceTypes.includes('Other') && (
                                     <input type="text" name="serviceTypeOther" placeholder="Please specify other service type" value={formData.serviceTypeOther} onChange={handleChange} className="mt-2 block w-full border-gray-300 rounded-md shadow-sm bg-white text-base py-2 px-3 focus:border-indigo-500 focus:ring-indigo-500"/>
                                )}
                            </div>
                        </div>

                        {/* Section 2: Worship Summary */}
                         <div className={`${formSectionClasses} bg-blue-50`}>
                            <h3 className="text-lg font-semibold text-slate-700 -mt-2 mb-2">Worship Summary</h3>
                            <FormInput label="Theme / Sermon Topic" name="sermonTopic" value={formData.sermonTopic} onChange={handleChange} />
                            <FormInput label="Worship Highlights / Notes" name="worshipHighlights" value={formData.worshipHighlights} onChange={handleChange} as="textarea" rows={4} />
                            <FormInput label="Announcements By" name="announcementsBy" value={formData.announcementsBy} onChange={handleChange} />
                        </div>
                        
                        {/* Section 3: Attendance */}
                        <div className={`${formSectionClasses} bg-green-50`}>
                            <h3 className="text-lg font-semibold text-slate-700 -mt-2 mb-2">Attendance</h3>
                             <div className="p-4 bg-green-100 border border-green-200 rounded-lg text-center">
                                <p className="text-sm font-medium text-green-700">Total Attendance</p>
                                <p className="text-4xl font-bold text-green-800">{totalAttendance}</p>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                {Object.keys(formData.attendance).map(key => (
                                    <div key={key}>
                                        <label htmlFor={`attendance.${key}`} className="block font-medium text-gray-700 capitalize">{key}</label>
                                        <input type="number" name={`attendance.${key}`} value={String(formData.attendance[key as keyof typeof formData.attendance])} onChange={handleNumberChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm bg-white text-base py-2 px-3 focus:border-indigo-500 focus:ring-indigo-500"/>
                                    </div>
                                ))}
                            </div>
                        </div>
                        
                        {/* Section 4: New Members & Donations */}
                        <div className={`${formSectionClasses} bg-yellow-50`}>
                            <h3 className="text-lg font-semibold text-slate-700 -mt-2 mb-2">New Members & Special Donations</h3>
                            <FormInput 
                                label="New Members (list names)" 
                                name="newMembersDetails" 
                                value={formData.newMembersDetails} 
                                onChange={handleChange} 
                                as="textarea" 
                                rows={3} 
                            />
                            <FormInput 
                                label="New Members Contact Info (Phone)" 
                                name="newMembersContact" 
                                value={formData.newMembersContact} 
                                onChange={handleChange} 
                                as="textarea" 
                                rows={3} 
                            />
                            <FormInput 
                                label="Special Donations (include description and donor)" 
                                name="specialDonationsDetails" 
                                value={formData.specialDonationsDetails} 
                                onChange={handleChange} 
                                as="textarea" 
                                rows={4} 
                            />
                        </div>

                        {/* Section 5: Events & Observations */}
                        <div className={`${formSectionClasses} bg-purple-50`}>
                            <h3 className="text-lg font-semibold text-slate-700 -mt-2 mb-2">Events & Observations</h3>
                            <FormInput label="Special Events or Activities This Week" name="events" value={formData.events} onChange={handleChange} as="textarea" />
                            <FormInput label="Observations / Challenges / Recommendations" name="observations" value={formData.observations} onChange={handleChange} as="textarea" />
                            <FormInput label="Prepared By (Name & Role)" name="preparedBy" value={formData.preparedBy} onChange={handleChange} />
                        </div>
                     </div>
                     <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200/80 flex justify-between items-center sticky bottom-0">
                         <div>
                            {selectedRecordId && (
                                <button type="button" onClick={handleDelete} className="text-red-600 hover:text-red-800 font-medium">Delete Record</button>
                            )}
                         </div>
                         <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg">
                            Save Record
                         </button>
                     </div>
                 </form>
            </section>
        </div>
    );
};

export default WeeklyHistory;