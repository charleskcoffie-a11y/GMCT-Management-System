import React, { useState, useMemo } from 'react';
import type { Member, AttendanceRecord, AttendanceStatus, Settings, User } from '../types';
import AttendanceReportModal from './AttendanceReportModal';
import { sanitizeAttendanceStatus, sanitizeString } from '../utils';

interface AdminAttendanceViewProps {
    members: Member[];
    attendance: AttendanceRecord[];
    settings: Settings;
    currentUser: User;
}

const AdminAttendanceView: React.FC<AdminAttendanceViewProps> = ({ members, attendance, settings, currentUser }) => {
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
    const [selectedMember, setSelectedMember] = useState<Member | null>(null);
    const [classFilter, setClassFilter] = useState<string>('all');

    const viewTitle = useMemo(() => {
        if (currentUser.role === 'class-leader') {
            return `Attendance Report for Class ${sanitizeString(currentUser.classLed)}`;
        }
        return 'Attendance Report';
    }, [currentUser]);

    const classOptions = useMemo(() => {
        return ['all', ...Array.from({ length: settings.maxClasses }, (_, i) => String(i + 1))];
    }, [settings.maxClasses]);

    const membersForReport = useMemo(() => {
        // Class leaders can only see their own class
        if (currentUser.role === 'class-leader') {
            return members.filter(m => m.classNumber === currentUser.classLed);
        }
        // Admins can filter by class
        if (classFilter === 'all') {
            return members;
        }
        return members.filter(m => m.classNumber === classFilter);
    }, [members, classFilter, currentUser]);
    
    const attendanceForDate = useMemo(() => {
        const record = attendance.find(r => r.date === selectedDate);
        const map = new Map<string, AttendanceStatus>();
        if (record) {
            record.records.forEach(r => map.set(r.memberId, r.status));
        }
        return map;
    }, [attendance, selectedDate]);

    const getStatusForMember = (memberId: string): AttendanceStatus => {
        const status = attendanceForDate.get(memberId);
        return sanitizeAttendanceStatus(status);
    };

    const stats = useMemo(() => {
        const total = membersForReport.length;
        if (total === 0) return { present: 0, absent: 0, sick: 0, travel: 0, catechumen: 0, total };
        
        const counts: Record<AttendanceStatus, number> = { present: 0, absent: 0, sick: 0, travel: 0, catechumen: 0 };
        
        membersForReport.forEach(m => {
             const status = getStatusForMember(m.id);
             if (counts.hasOwnProperty(status)) {
                counts[status]++;
             }
        })
        return {...counts, total};
    }, [membersForReport, attendanceForDate]);

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-800">{viewTitle}</h2>

            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200/80 flex flex-wrap items-center gap-4">
                <div>
                    <label htmlFor="reportDate" className="block font-medium text-slate-700 mb-1">Report Date</label>
                    <input
                        id="reportDate"
                        type="date"
                        value={selectedDate}
                        onChange={e => setSelectedDate(e.target.value)}
                        className="border-slate-300 rounded-md text-base py-2 px-3"
                    />
                </div>
                {currentUser.role === 'admin' && (
                    <div>
                        <label htmlFor="classFilter" className="block font-medium text-slate-700 mb-1">Filter by Class</label>
                        <select
                            id="classFilter"
                            value={classFilter}
                            onChange={e => setClassFilter(e.target.value)}
                            className="border-slate-300 rounded-md text-base py-2 px-3"
                        >
                            {classOptions.map(cls => (
                                <option key={cls} value={cls}>
                                    {cls === 'all' ? 'All Classes' : `Class ${cls}`}
                                </option>
                            ))}
                        </select>
                    </div>
                )}
            </div>
            
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="bg-green-100 text-green-800 p-4 rounded-lg text-center"><div className="font-bold text-2xl">{stats.present}</div><div className="text-sm">Present</div></div>
                <div className="bg-red-100 text-red-800 p-4 rounded-lg text-center"><div className="font-bold text-2xl">{stats.absent}</div><div className="text-sm">Absent</div></div>
                <div className="bg-yellow-100 text-yellow-800 p-4 rounded-lg text-center"><div className="font-bold text-2xl">{stats.sick}</div><div className="text-sm">Sick</div></div>
                <div className="bg-blue-100 text-blue-800 p-4 rounded-lg text-center"><div className="font-bold text-2xl">{stats.travel}</div><div className="text-sm">Travel</div></div>
                <div className="bg-purple-100 text-purple-800 p-4 rounded-lg text-center"><div className="font-bold text-2xl">{stats.catechumen}</div><div className="text-sm">Catechumen</div></div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200/80 overflow-x-auto">
                <table className="w-full text-left text-slate-500">
                    <thead className="text-base text-slate-700 uppercase bg-slate-50">
                        <tr>
                            <th className="px-6 py-3">Member Name</th>
                            <th className="px-6 py-3">Class #</th>
                            <th className="px-6 py-3">Status</th>
                            <th className="px-6 py-3"></th>
                        </tr>
                    </thead>
                    <tbody className="text-base">
                        {membersForReport.map(member => (
                            <tr key={member.id} className="bg-white border-b hover:bg-slate-50">
                                <td className="px-6 py-4 font-medium text-slate-900">{sanitizeString(member.name)}</td>
                                <td className="px-6 py-4">{sanitizeString(member.classNumber) || 'N/A'}</td>
                                <td className="px-6 py-4 capitalize">{getStatusForMember(member.id)}</td>
                                <td className="px-6 py-4 text-right">
                                    <button onClick={() => setSelectedMember(member)} className="font-medium text-blue-600 hover:underline">View History</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {selectedMember && (
                <AttendanceReportModal 
                    member={selectedMember}
                    attendance={attendance}
                    onClose={() => setSelectedMember(null)}
                />
            )}
        </div>
    );
};

export default AdminAttendanceView;